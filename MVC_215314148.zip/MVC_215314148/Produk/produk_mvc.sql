-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 18 Jun 2023 pada 17.57
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `produk_mvc`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `produkmvc`
--

CREATE TABLE `produkmvc` (
  `id` int(90) DEFAULT NULL,
  `NamaProduk` varchar(90) NOT NULL,
  `Harga` int(90) NOT NULL,
  `Exp` varchar(90) NOT NULL,
  `Brand` varchar(90) NOT NULL,
  `DistributorProduk` varchar(90) NOT NULL,
  `FotoProduk` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `produkmvc`
--

INSERT INTO `produkmvc` (`id`, `NamaProduk`, `Harga`, `Exp`, `Brand`, `DistributorProduk`, `FotoProduk`) VALUES
(1, 'Bimoli', 22000, '25102023', 'Unilever', 'PT.Minyak', 'bimoli'),
(2, 'Detol', 30000, '23012024', 'Unilever', 'PT.SehatAbadi', 'detol'),
(3, 'Lifeboy', 8000, '21062025', 'Unilever', 'PT.SehatSelamnya', 'lifeboy');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

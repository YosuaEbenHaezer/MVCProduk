<?php

echo "<table>
<td><img src='" . BASEURL . "/image/" . $data['barang']['FotoProduk'] . ".jpg' width='175'></td>
<td>Nama:".$data['barang']['NamaProduk']."
<br>
Harga: ".$data['barang']['Harga']."
<br>
Exp: ".$data['barang']['Exp']."
<br>
Merk: ".$data['barang']['Brand']."
<br>
Distributor: ".$data['barang']['DistributorProduk']."
<br>
</td>
<table>
<br>";
echo "<a href='" . BASEURL . "/home' class='card-link'>Kembali</a>";
<?php

class Produk_model{
    private $table = 'produkmvc';
    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }

    public function getAllProduk(){
        $this->db->query('SELECT * FROM '.$this->table);
        return $this->db->resultSet();
    }

    public function getProdukById($id){
        $this->db->query('SELECT * FROM ' . $this->table . ' Where id=:id');
        $this->db->bind('id', $id);
        return $this->db->single();
    }
}
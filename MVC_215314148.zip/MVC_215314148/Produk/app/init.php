<?php
require_once 'core/App.php';
require_once 'core/Controllers.php';
require_once 'core/Database.php';
require_once 'config/config.php';